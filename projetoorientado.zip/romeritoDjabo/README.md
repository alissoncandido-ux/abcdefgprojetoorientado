Eu mudei o atributo da classe livro de usuarios para usuario

criei a rota logout() no app.py

utilizei o seed para cadastrar o usuario inicialmente

e é isso, consegui fazer nn