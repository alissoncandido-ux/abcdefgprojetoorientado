from flask import Flask, render_template, request, url_for, redirect
from sqlalchemy import select
from sqlalchemy.orm import Session
from database import Base, engine

from models import Livro, Usuario

app = Flask(__name__)
Base.metadata.create_all(engine)


@app.route('/')
def index():
    with Session(engine) as session:
        Usuarios = session.scalars(select(Usuario)).all()
        livros = session.scalars(select(Livro)).all()
    return render_template('index.html', Usuarios=Usuarios, livros=livros)


@app.route('/Usuario/novo', methods=['POST', 'GET'])
def form_Usuario():
    if request.method == 'POST':
        usuario = Usuario(
            nome=request.form.get('nome'),
            email=request.form.get('email')
        )
        with Session(engine) as session:
            session.add(usuario)
            session.commit()
        return redirect(url_for('index'))
    return render_template('form_Usuario.html')


@app.route('/livros/novo', methods=['GET', 'POST'])
def form_livro():
    with Session(engine) as session:
        Usuarios = session.scalars(select(Usuario).order_by(Usuario.nome)).all()
        if request.method == 'POST':
            livro = Livro(
                titulo=request.form.get('titulo'),
                Usuario_id=int(request.form.get('Usuario_id'))
            )
            session.add(livro)
            session.commit()
            return redirect(url_for('index'))
    return render_template('form_livro.html', Usuarios=Usuarios)

@app.route('/livros/listar', methods=['GET'])
def listar_livros():
    with Session(engine) as session:
        statement = select(Livro).order_by(Livro.titulo)
        livros = session.scalars(statement).all()

        return render_template('index.html', livros=livros)

@app.route('/Usuarios/listar', methods=['GET'])
def listar_Usuarios():
    with Session(engine) as session:
        statement = select(Usuario).order_by(Usuario.nome)
        Usuarios = session.scalars(statement).all()

        return render_template('index.html', Usuarios=Usuarios)

@app.route('/logout')
def logout():
    return redirect(url_for('form_Usuario'))

if __name__ == "__main__":
    app.run(debug=True)