from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, session

class Base(DeclarativeBase):
    pass

engine = create_engine("sqlite:///biblioteca.db")